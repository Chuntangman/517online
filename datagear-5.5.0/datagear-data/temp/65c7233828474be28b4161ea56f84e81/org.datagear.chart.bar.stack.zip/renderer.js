(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options={ dg: { stack: true } };
			chartFactory.chartSupport.barRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.barUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.barResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.barDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.barOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.barOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);