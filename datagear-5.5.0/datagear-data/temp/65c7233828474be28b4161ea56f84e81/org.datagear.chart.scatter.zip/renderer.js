(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.scatterRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.scatterUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.scatterResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.scatterDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);