(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.scatterCoordRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.scatterCoordUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.scatterCoordResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.scatterCoordDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterCoordOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterCoordOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);