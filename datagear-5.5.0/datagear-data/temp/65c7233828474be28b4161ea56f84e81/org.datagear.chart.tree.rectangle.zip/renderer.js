(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.treemapRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.treemapUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.treemapResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.treemapDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.treemapOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.treemapOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);