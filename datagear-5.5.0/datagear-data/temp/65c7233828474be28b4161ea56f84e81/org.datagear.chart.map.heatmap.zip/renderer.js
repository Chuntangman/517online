(function(plugin)
{
	var r =
	{
		asyncRender: true,
		render: function(chart)
		{
			chartFactory.chartSupport.mapHeatmapRender(chart);
		},
		asyncUpdate: true,
		update: function(chart, results)
		{
			chartFactory.chartSupport.mapHeatmapUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.mapHeatmapResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.mapHeatmapDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapHeatmapOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapHeatmapOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);