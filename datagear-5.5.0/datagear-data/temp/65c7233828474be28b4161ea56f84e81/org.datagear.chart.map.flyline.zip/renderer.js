(function(plugin)
{
	var r =
	{
		asyncRender: true,
		render: function(chart)
		{
			chartFactory.chartSupport.mapFlylineRender(chart);
		},
		asyncUpdate: true,
		update: function(chart, results)
		{
			chartFactory.chartSupport.mapFlylineUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.mapFlylineResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.mapFlylineDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapFlylineOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapFlylineOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);