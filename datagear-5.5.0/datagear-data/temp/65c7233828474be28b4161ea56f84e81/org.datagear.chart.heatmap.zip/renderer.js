(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.heatmapRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.heatmapUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.heatmapResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.heatmapDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.heatmapOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.heatmapOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);