(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = { dg: { step: true } };
			chartFactory.chartSupport.lineRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.lineUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.lineResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.lineDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.lineOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.lineOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);