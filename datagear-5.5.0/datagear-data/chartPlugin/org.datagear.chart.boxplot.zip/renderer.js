(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.boxplotRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.boxplotUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.boxplotResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.boxplotDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.boxplotOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.boxplotOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);