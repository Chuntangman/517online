(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "DataTable",
			version: "1.11.3",
			source:
			[
				"lib/DataTables-1.11.3/bundle-datatables.min.css",
				"lib/DataTables-1.11.3/bundle-datatables.min.js"
			]
		},
		render: function(chart)
		{
			chartFactory.chartSupport.tableRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.tableUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.tableResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.tableDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.tableOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.tableOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);