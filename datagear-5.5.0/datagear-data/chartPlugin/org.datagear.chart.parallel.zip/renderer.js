(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.parallelRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.parallelUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.parallelResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.parallelDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.parallelOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.parallelOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);