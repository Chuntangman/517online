(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.pictorialBarRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.pictorialBarUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.pictorialBarResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.pictorialBarDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);