(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options={ valueFirst: true };
			chartFactory.chartSupport.labelRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.labelUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.labelResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.labelDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.labelOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.labelOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);