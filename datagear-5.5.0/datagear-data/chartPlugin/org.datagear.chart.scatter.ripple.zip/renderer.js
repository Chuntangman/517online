(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.scatterRippleRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.scatterRippleUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.scatterRippleResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.scatterRippleDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterRippleOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterRippleOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);