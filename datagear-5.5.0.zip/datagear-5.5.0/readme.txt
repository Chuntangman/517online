DataGear-v5.5.0

DataGear是一款开源免费的数据可视化分析平台，自由制作任何您想要的数据看板。

系统要求：
	JDK 8+

启动：
	Linux：
	./startup.sh
	
	Windows:
	startup.bat
	
	打开浏览器，输入服务地址：
	http://【IP地址】:50401
	开始使用。

官网：
	http://www.datagear.tech

入门：
	http://www.datagear.tech/quickstart/

文档：
	http://www.datagear.tech/documentation/

源码：
	https://gitee.com/datagear/datagear
	https://github.com/datageartech/datagear
